<?php

if (!defined('GALLERY_MODULE_SCREEN_NAME')) {
    define('GALLERY_MODULE_SCREEN_NAME', 'gallery');
}
