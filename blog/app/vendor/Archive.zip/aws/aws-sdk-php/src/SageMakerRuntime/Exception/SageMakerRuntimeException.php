<?php
namespace Aws\SageMakerRuntime\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **Amazon SageMaker Runtime** service.
 */
class SageMakerRuntimeException extends AwsException {}
