<?php

namespace Botble\Slug\Repositories\Caches;

use Botble\Slug\Repositories\Interfaces\SlugInterface;
use Botble\Support\Repositories\Caches\CacheAbstractDecorator;

class SlugCacheDecorator extends CacheAbstractDecorator implements SlugInterface
{

}
