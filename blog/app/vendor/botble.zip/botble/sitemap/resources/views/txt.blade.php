@foreach ($items as $item)
    {{ $item['loc'] }}
@endforeach
