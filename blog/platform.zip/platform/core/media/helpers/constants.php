<?php

if (!defined('MEDIA_GROUP_CACHE_KEY')) {
    define('MEDIA_GROUP_CACHE_KEY', 'Botble\Media\Repositories');
}
