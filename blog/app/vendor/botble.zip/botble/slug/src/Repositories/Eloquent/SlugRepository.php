<?php

namespace Botble\Slug\Repositories\Eloquent;

use Botble\Slug\Repositories\Interfaces\SlugInterface;
use Botble\Support\Repositories\Eloquent\RepositoriesAbstract;

class SlugRepository extends RepositoriesAbstract implements SlugInterface
{
}
