<?php

return [
    'templates' => [
        'default' => 'Default',
    ],
];