<?php

namespace Botble\Slug\Traits;

/**
 * @deprecated 5.9
 */
trait SlugTrait
{
}
