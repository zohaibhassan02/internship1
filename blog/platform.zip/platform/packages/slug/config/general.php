<?php

return [
    'pattern'   => '--slug--',
    'supported' => [
        'Botble\Page\Models\Page' => 'Pages',
    ],
    'prefixes'  => [

    ],
    'disable_preview' => [

    ],
];
