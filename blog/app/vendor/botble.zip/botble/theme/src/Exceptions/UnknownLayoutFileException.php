<?php

namespace Botble\Theme\Exceptions;

use UnexpectedValueException;

class UnknownLayoutFileException extends UnexpectedValueException
{
}
