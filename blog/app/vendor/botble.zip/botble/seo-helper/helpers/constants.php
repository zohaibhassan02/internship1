<?php

if (!defined('SEO_HELPER_FILTER_SCREEN_USING')) {
    define('SEO_HELPER_FILTER_SCREEN_USING', 'seo_helper_filter_screen_using');
}
