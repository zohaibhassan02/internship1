<?php

return [
    'backup_mysql_execute_path' => env('BACKUP_MYSQL_EXECUTE_PATH', '')
];
