<?php

return [
    'permalink_settings' => 'Permalink',
    'settings'           => [
        'title'       => 'Permalink settings',
        'description' => 'Manage permalink for all modules.',
        'preview'     => 'Preview',
    ],
    'preview'            => 'Preview',
];
