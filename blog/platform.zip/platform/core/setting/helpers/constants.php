<?php

if (!defined('BASE_FILTER_AFTER_SETTING_CONTENT')) {
    define('BASE_FILTER_AFTER_SETTING_CONTENT', 'base-filter-after-setting-content');
}

if (!defined('BASE_FILTER_AFTER_SETTING_EMAIL_CONTENT')) {
    define('BASE_FILTER_AFTER_SETTING_EMAIL_CONTENT', 'base-filter-after-setting-email-content');
}

if (!defined('SETTINGS_PREPARE_INSERT_DATA')) {
    define('SETTINGS_PREPARE_INSERT_DATA', 'settings_prepare_insert_data');
}
