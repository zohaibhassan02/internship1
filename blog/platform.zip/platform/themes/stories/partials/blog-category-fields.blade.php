<div class="form-group">
    <label for="icon" class="control-label">{{ __('Image') }}</label>
    {!! Form::mediaImage('image', $image) !!}
</div>
