<div class="form-group">
    <label class="control-label">Title</label>
    <input name="title" data-shortcode-attribute="title" class="form-control" />
</div>
<?php /**PATH /Users/mac/workspace/stories/platform/themes/stories/partials/short-codes/about-banner-admin-config.blade.php ENDPATH**/ ?>