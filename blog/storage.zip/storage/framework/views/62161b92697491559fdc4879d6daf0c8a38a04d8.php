<div class="form-group">
    <label class="control-label">Address</label>
    <input name="address" data-shortcode-attribute="content" class="form-control" placeholder="24 Roberts Street, SA73, Chester">
</div>
<?php /**PATH /Users/mac/workspace/stories/platform/themes/stories/partials/short-codes/google-map-admin-config.blade.php ENDPATH**/ ?>