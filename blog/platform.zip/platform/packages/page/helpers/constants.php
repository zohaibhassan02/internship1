<?php

if (!defined('PAGE_MODULE_SCREEN_NAME')) {
    define('PAGE_MODULE_SCREEN_NAME', 'page');
}

if (!defined('PAGE_FILTER_PAGE_NAME_IN_ADMIN_LIST')) {
    define('PAGE_FILTER_PAGE_NAME_IN_ADMIN_LIST', 'page_name_in_admin_list');
}

if (!defined('PAGE_FILTER_FRONT_PAGE_CONTENT')) {
    define('PAGE_FILTER_FRONT_PAGE_CONTENT', 'page_front_page_content');
}