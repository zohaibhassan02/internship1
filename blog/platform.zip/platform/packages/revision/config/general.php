<?php

use Botble\Page\Models\Page;

return [
    // List supported modules or plugins
    'supported' => [
        Page::class,
    ],
];
