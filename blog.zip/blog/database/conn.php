<?php
//database connection
($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost","root","password","blog_admin_db"));  //host,user,password,database
?>
