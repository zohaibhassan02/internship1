<?php

if (!defined('SLUG_MODULE_SCREEN_NAME')) {
    define('SLUG_MODULE_SCREEN_NAME', 'slug');
}

if (!defined('BASE_FILTER_SLUG_AREA')) {
    define('BASE_FILTER_SLUG_AREA', 'slug-area');
}

if (!defined('FILTER_SLUG_PREFIX')) {
    define('FILTER_SLUG_PREFIX', 'slug-prefix-filter');
}

if (!defined('FILTER_SLUG_EXISTED_STRING')) {
    define('FILTER_SLUG_EXISTED_STRING', 'slug-existed-string');
}

if (!defined('FILTER_SLUG_STRING')) {
    define('FILTER_SLUG_STRING', 'slug-string');
}
