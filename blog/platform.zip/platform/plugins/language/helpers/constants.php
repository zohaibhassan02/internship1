<?php

if (!defined('LANGUAGE_MODULE_SCREEN_NAME')) {
    define('LANGUAGE_MODULE_SCREEN_NAME', 'language');
}

if (!defined('LANGUAGE_FILTER_ROUTE_ACTION')) {
    define('LANGUAGE_FILTER_ROUTE_ACTION', 'route_actions');
}

if (!defined('LANGUAGE_FILTER_SWITCHER')) {
    define('LANGUAGE_FILTER_SWITCHER', 'language_switcher');
}

if (!defined('LANGUAGE_FILTER_MODEL_USING_MULTI_LANGUAGE')) {
    define('LANGUAGE_FILTER_MODEL_USING_MULTI_LANGUAGE', 'model_using_multi_language');
}
