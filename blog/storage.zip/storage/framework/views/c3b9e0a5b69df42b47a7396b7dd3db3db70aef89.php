<div class="form-group">
    <label class="control-label"><?php echo e(trans('plugins/gallery::gallery.shortcode_name')); ?></label>
    <input type="number" name="limit" class="form-control" data-shortcode-attribute="attribute" placeholder="<?php echo e(trans('plugins/gallery::gallery.limit_display')); ?>">
</div>
<?php /**PATH /Users/mac/workspace/stories/platform/plugins/gallery/resources/views//partials/short-code-admin-config.blade.php ENDPATH**/ ?>