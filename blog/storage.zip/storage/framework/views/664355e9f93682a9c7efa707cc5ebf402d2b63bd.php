<div class="form-group">
    <label class="control-label">Title</label>
    <input type="text" name="title" data-shortcode-attribute="title" class="form-control" />
</div>
<?php /**PATH /Users/mac/workspace/stories/platform/themes/stories/partials/short-codes/featured-posts-admin-config.blade.php ENDPATH**/ ?>