<div class="form-group">
    <label class="control-label">Limit</label>
    <input type="number" name="limit" data-shortcode-attribute="limit" class="form-control" />
</div>
<?php /**PATH /Users/mac/workspace/stories/platform/themes/stories/partials/short-codes/blog-list-admin-config.blade.php ENDPATH**/ ?>