<?php

return [
    [
        'name'        => 'Widgets',
        'flag'        => 'widgets.index',
        'parent_flag' => 'core.appearance',
    ],
];