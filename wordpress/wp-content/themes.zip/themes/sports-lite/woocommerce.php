<?php get_header(); ?>
<div class="container">
<div id="sitetabnavi">
     <div class="innerpage_content_layout fullwidth">  
			<?php woocommerce_content(); ?>
    </div><!-- innerpage_content_layout-->   
</div><!-- #sitetabnavi --> 
</div><!-- .container -->     
<?php get_footer(); ?>