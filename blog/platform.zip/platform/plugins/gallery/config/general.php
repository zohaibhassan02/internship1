<?php

return [
    // List supported modules or plugins
    'supported' => [
        'Botble\Gallery\Models\Gallery',
        'Botble\Page\Models\Page',
        'Botble\Blog\Models\Post',
    ],
];
