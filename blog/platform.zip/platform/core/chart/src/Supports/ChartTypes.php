<?php

namespace Botble\Chart\Supports;

class ChartTypes
{
    const LINE = 'Line';
    const BAR = 'Bar';
    const DONUT = 'Donut';
    const AREA = 'Area';
}
