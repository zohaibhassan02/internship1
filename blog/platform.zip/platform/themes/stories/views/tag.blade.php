@include(Theme::getThemeNamespace() . '::views.templates.posts', compact('posts'))
